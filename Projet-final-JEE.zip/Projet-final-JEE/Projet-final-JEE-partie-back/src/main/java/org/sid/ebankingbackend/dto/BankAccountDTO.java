package org.sid.ebankingbackend.dto;

import lombok.Data;

@Data
public class BankAccountDTO {
    private String type;
}
